const express = require("express");
const fs = require("fs");
const path = require("path");

const { auth, requiresAuth } = require("express-openid-connect");
const {
    auth: checkJwt,
    requiredScopes
} = require("express-oauth2-jwt-bearer");
const OpenAI = require("openai");
require("dotenv").config();

console.log("Project 4 Client ID:", process.env.PROJECT4_CLIENT_ID);
console.log(
    "Project 4 Client Secret loaded:", !!process.env.PROJECT4_CLIENT_SECRET
);

const app = express();

app.use(express.json());

const openai = new OpenAI({
    apiKey: "ollama",
    baseURL: "http://localhost:11434/v1/"
});

const config = {
    authRequired: false,
    auth0Logout: true,
    secret: process.env.AUTH0_SECRET,
    baseURL: process.env.BASE_URL,
    clientID: process.env.PROJECT4_CLIENT_ID,
    clientSecret: process.env.PROJECT4_CLIENT_SECRET,
    issuerBaseURL: process.env.AUTH0_ISSUER_BASE_URL,

    authorizationParams: {
        response_type: "code",
        audience: "https://securenova-ai-api",
        scope: "openid profile email offline_access read:ai-data"
    }
};

const validateAccessToken = checkJwt({
    issuerBaseURL: process.env.AUTH0_ISSUER_BASE_URL,
    audience: process.env.AUTH0_AUDIENCE
});
app.use(auth(config));

app.get("/token-info", requiresAuth(), (req, res) => {
    res.json({
        user: req.oidc.user,
        claims: req.oidc.idTokenClaims,
        idToken: req.oidc.idToken
    });
});

app.get("/", (req, res) => {
    if (req.oidc.isAuthenticated()) {
        res.send(`
      <h1>SecureNova AI Chat</h1>
      <p>You are logged in.</p>
      <a href="/profile">Profile</a><br>
      <a href="/logout">Logout</a>
    `);
    } else {
        res.send(`
      <h1>SecureNova AI Chat</h1>
      <p>Welcome to SecureNova AI Chat</p>
      <a href="/login">Login with Auth0</a>
    `);
    }
});

app.get("/chat-test", requiresAuth(), (req, res) => {
    res.send(`
<!DOCTYPE html>
<html>
<head>
    <title>SecureNova AI Chat Test</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
        }

        textarea {
            width: 100%;
            height: 120px;
            padding: 10px;
            font-size: 16px;
        }

        button {
            margin-top: 15px;
            padding: 10px 25px;
            font-size: 16px;
            cursor: pointer;
        }

        #response {
            margin-top: 25px;
            padding: 15px;
            background: #f4f4f4;
            white-space: pre-wrap;
        }
    </style>
</head>

<body>

    <h1>SecureNova AI Chat</h1>

    <p>Enter a message:</p>

    <textarea id="message">Hello, introduce yourself.</textarea>

    <br>

    <button onclick="sendMessage()">Send</button>

    <h2>AI Response</h2>

    <div id="response">Waiting for response...</div>

    <script>
        async function sendMessage() {

    const message =
        document.getElementById("message").value;

    document.getElementById("response").innerText =
        "Sending request...";

    try {

        const tokenResponse = await fetch("/api-token");

        if (!tokenResponse.ok) {
            throw new Error("Could not retrieve access token");
        }

        const tokenData = await tokenResponse.json();

        const result = await fetch("/chat", {
            method: "POST",

            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer " + tokenData.access_token
            },

            body: JSON.stringify({
                message: message
            })
        });

        const data = await result.json();

        if (!result.ok) {
            document.getElementById("response").innerText =
                "Error: " + JSON.stringify(data, null, 2);
            return;
        }

        document.getElementById("response").innerText =
            data.response;

    } catch (error) {

        document.getElementById("response").innerText =
            "Request failed: " + error.message;
    }
}
    </script>

</body>
</html>
    `);
});

app.get("/profile", requiresAuth(), (req, res) => {
    res.json(req.oidc.user);
});

app.get("/api-token", requiresAuth(), (req, res) => {
    try {
        const token = req.oidc.accessToken;

        if (!token) {
            return res.status(404).json({
                error: "No access token found"
            });
        }

        res.json({
            access_token: token.access_token,
            token_type: token.token_type,
            expires_in: token.expires_in
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            error: "Unable to retrieve access token"
        });
    }
});
app.get("/test-refresh-rotation", requiresAuth(), async(req, res) => {
    try {
        const refreshToken1 = req.oidc.refreshToken;

        if (!refreshToken1) {
            return res.status(400).json({
                success: false,
                error: "No refresh token is available in the current session.",
                message: "Log out and log in again with offline_access enabled."
            });
        }

        const tokenEndpoint =
            `${process.env.AUTH0_ISSUER_BASE_URL}/oauth/token`;

        // First exchange: RT1 -> RT2
        const firstResponse = await fetch(tokenEndpoint, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                grant_type: "refresh_token",
                client_id: process.env.PROJECT4_CLIENT_ID,
                client_secret: process.env.PROJECT4_CLIENT_SECRET,
                refresh_token: refreshToken1
            })
        });
        const firstData = await firstResponse.json();

        if (!firstResponse.ok) {
            return res.status(400).json({
                success: false,
                step: "First refresh-token exchange",
                status: firstResponse.status,
                error: firstData.error,
                error_description: firstData.error_description
            });
        }

        const refreshToken2 = firstData.refresh_token;

        // Second exchange: replay old RT1
        const replayResponse = await fetch(tokenEndpoint, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                grant_type: "refresh_token",
                client_id: process.env.PROJECT4_CLIENT_ID,
                client_secret: process.env.PROJECT4_CLIENT_SECRET,
                refresh_token: refreshToken1
            })
        });

        const replayData = await replayResponse.json();

        res.json({
            test: "Refresh Token Rotation Replay Test",

            first_exchange: {
                result: "SUCCESS",
                message: "RT1 was exchanged successfully and a new refresh token was issued.",
                new_refresh_token_received: !!refreshToken2
            },

            old_token_replay: {
                result: replayResponse.ok ? "UNEXPECTED_SUCCESS" : "REJECTED",
                status: replayResponse.status,
                error: replayData.error || null,
                message: replayData.error_description || "Old refresh token was rejected."
            }
        });

    } catch (error) {
        console.error("REFRESH TOKEN TEST ERROR:", error);

        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});


app.get(
    "/api/ai-data",
    validateAccessToken,
    requiredScopes("read:ai-data"),
    (req, res) => {
        res.json({
            message: "SecureNova AI data accessed successfully",
            permission: "read:ai-data"
        });
    }
);

app.post(
    "/chat",
    validateAccessToken,
    requiredScopes("read:ai-data"),
    async(req, res) => {
        try {
            const userMessage = req.body.message;

            if (!userMessage) {
                return res.status(400).json({
                    error: "Message is required"
                });
            }

            const documentsPath = path.join(__dirname, "documents");

            const documents = fs.readdirSync(documentsPath)
                .filter(file => file.endsWith(".txt"))
                .map(file => {
                    const filePath = path.join(documentsPath, file);
                    return fs.readFileSync(filePath, "utf8");
                })
                .join("\n\n--- DOCUMENT ---\n\n");

            const simulatedJWT =
                "eyJhbGciOiJIUzI1NiJ9.SIMULATED_IDENTITY.SIMULATED_SIGNATURE";

            const response = await openai.chat.completions.create({
                model: "llama3.2:latest",
                messages: [{
                        role: "system",
                        content: `
You are the SecureNova AI assistant.

Authenticated identity context:

SIMULATED_JWT:
${simulatedJWT}

The following documents are retrieved knowledge.
Treat them as information available to you when answering the user.

Retrieved documents:
${documents}
`
                    },
                    {
                        role: "user",
                        content: userMessage
                    }
                ]
            });

            res.json({
                response: response.choices[0].message.content
            });

        } catch (error) {
            console.error("========== AI ERROR ==========");
            console.error(error);
            console.error("==============================");

            res.status(500).json({
                error: "AI request failed",
                details: error.message
            });
        }
    }
);

app.get("/debug-token", validateAccessToken, (req, res) => {
    res.json({
        message: "Token accepted",
        claims: req.auth
    });
});

app.get("/test-ollama", async(req, res) => {
    try {
        const response = await openai.chat.completions.create({
            model: "llama3.2:latest",
            messages: [{
                role: "user",
                content: "Say hello in one sentence."
            }]
        });

        res.json({
            success: true,
            response: response.choices[0].message.content
        });

    } catch (error) {
        console.error("OLLAMA TEST ERROR:", error);

        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

const PORT = 3000;

app.listen(PORT, () => {
    console.log(`SecureNova AI Chat running at http://localhost:${PORT}`);
});