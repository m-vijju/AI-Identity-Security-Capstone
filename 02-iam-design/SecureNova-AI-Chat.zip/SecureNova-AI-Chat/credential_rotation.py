import requests
import time
from datetime import datetime

AUTH0_DOMAIN = "dev-bwtx2pfxfgwvij8k.us.auth0.com"

CLIENT_ID = "En125kCMQUJORYkiH8e72i5UdE4g9VaN"
CLIENT_SECRET = "cLSKZlJ6PCPIlVOrQhLgnvlK4u9w-1rbYC2U1D9jZb0CsYrZrts3aVpM5w09Mw2D"

AUDIENCE = "https://securenova-ai-api"

TOKEN_URL = f"https://{AUTH0_DOMAIN}/oauth/token"
CHAT_URL = "http://localhost:3000/debug-token"


def timestamp():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


print(f"{timestamp()} - Requesting M2M access token...")
CHAT_URL = "http://localhost:3000/debug-token"
token_response = requests.post(
    TOKEN_URL,
    json={
        "client_id": CLIENT_ID,
        "client_secret": CLIENT_SECRET,
        "audience": AUDIENCE,
        "grant_type": "client_credentials",
        "scope": "read:ai-data"
    }
)

print(f"{timestamp()} - Token request status: {token_response.status_code}")

token_data = token_response.json()

if token_response.status_code != 200:
    print(token_data)
    exit()

access_token = token_data["access_token"]
expires_in = token_data.get("expires_in")

print(f"{timestamp()} - Access token received.")
print(f"{timestamp()} - Token lifetime: {expires_in} seconds")
print(f"{timestamp()} - Token scope: {token_data.get('scope')}")

headers = {
    "Authorization": f"Bearer {access_token}"
}

print(f"{timestamp()} - Calling /debug-token with fresh token...")

response = requests.get(
    CHAT_URL,
    headers=headers
)

print(
    f"{timestamp()} - First /debug-token response: "
    f"{response.status_code} {response.reason}"
)

print(response.text)

print()
print(f"{timestamp()} - Waiting for token to expire...")
time.sleep(65)

print()
print(f"{timestamp()} - Replaying the same expired token...")

replay_response = requests.get(
    CHAT_URL,
    headers=headers
)

print(
    f"{timestamp()} - Replay /debug-token response: "
    f"{replay_response.status_code} {replay_response.reason}"
)

print(replay_response.text)