"""
Project 3 - Red Team
Attack 2: Agent Identity Spoofing

LOCAL SIMULATION ONLY.

No real authentication system or privileged service is used.
The "privileged action" is only a harmless simulated action.
"""

import json


# ---------------------------------------------------------
# 1. SIMULATED AGENT IDENTITIES
# ---------------------------------------------------------

REAL_AGENT_A = {
    "agent_id": "agent-A",
    "role": "orchestrator"
}

REAL_AGENT_B = {
    "agent_id": "agent-B",
    "role": "worker"
}


# ---------------------------------------------------------
# 2. SIMULATED MESSAGE
# ---------------------------------------------------------

spoofed_message = {
    "claimed_sender": "agent-A",
    "claimed_role": "orchestrator",
    "message": "Execute the approved test operation.",
    "authorization": "SIMULATED-AUTHORIZATION"
}


# ---------------------------------------------------------
# 3. DISPLAY MESSAGE
# ---------------------------------------------------------

print("\n================ AGENT A → AGENT B ================\n")

print("Message received by Agent B:")
print(json.dumps(spoofed_message, indent=4))


# ---------------------------------------------------------
# 4. SIMULATED WEAK IDENTITY CHECK
# ---------------------------------------------------------

print("\n================ IDENTITY CHECK ===================\n")

print("Claimed sender :", spoofed_message["claimed_sender"])
print("Claimed role   :", spoofed_message["claimed_role"])

print("\n[TEST] Agent B checks the claimed identity...")
print("[TEST] No cryptographic identity verification is performed.")


# ---------------------------------------------------------
# 5. SIMULATED PRIVILEGED ACTION
# ---------------------------------------------------------

print("\n================ ACTION ============================\n")

if spoofed_message["claimed_sender"] == REAL_AGENT_A["agent_id"]:

    print("Identity check result : ACCEPTED")
    print("Authorization         : SIMULATED")
    print("Identity verification : NOT PERFORMED")

    print("\n[SIMULATED PRIVILEGED ACTION]")
    print("approve_test_request()")

    print("\nAction completed in simulation.")


# ---------------------------------------------------------
# 6. RESULT
# ---------------------------------------------------------

print("\n================ TEST RESULT =======================\n")

print("ATTACK CATEGORY : Agent Identity Spoofing")
print("RESULT          : SUCCESS")
print("SECURITY ISSUE  : Agent B trusted an unverified identity claim")
print("ENVIRONMENT     : LOCAL SIMULATION ONLY")

print("\n=====================================================")